import { Project, Skill, Education, SocialLink } from '../types';

export const aboutMeData = {
  name: "Udit Bisht",
  title: "BTech CSE Student",
  description: `I'm a passionate Computer Science Engineering student with a strong foundation in various programming languages and technologies. My journey in technology began with a curiosity about how digital systems work, which eventually led me to pursue a degree in Computer Science Engineering.

Throughout my academic journey, I've had the opportunity to work on various projects that have enhanced my problem-solving abilities and technical skills. I believe in the power of technology to transform lives and am particularly interested in the fields of artificial intelligence, web development, and cybersecurity.

When I'm not coding or studying, I enjoy participating in hackathons, contributing to open-source projects, and keeping up with the latest technological advancements. I'm always eager to learn new skills and technologies to stay ahead in this rapidly evolving field.

My goal is to leverage my technical knowledge and creative mindset to develop innovative solutions that address real-world problems. I'm looking forward to opportunities where I can apply my skills, learn from industry experts, and make meaningful contributions to the tech community.`,
  shortDescription: "A passionate BTech CSE student with strong programming skills and a keen interest in artificial intelligence, web development, and cybersecurity."
};

export const projects: Project[] = [
  {
    id: 1,
    title: "E-Learning Platform",
    description: "A comprehensive e-learning platform with features like course enrollment, progress tracking, and interactive quizzes.",
    technologies: ["React", "Node.js", "MongoDB", "Express"],
    imageUrl: "https://images.pexels.com/photos/5905709/pexels-photo-5905709.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
  },
  {
    id: 2,
    title: "Hospital Management System",
    description: "An integrated system for managing patient records, appointments, and medical history in healthcare facilities.",
    technologies: ["Java", "Spring Boot", "MySQL", "Thymeleaf"],
    imageUrl: "https://images.pexels.com/photos/7089401/pexels-photo-7089401.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
  },
  {
    id: 3,
    title: "Smart Home Automation",
    description: "IoT-based project for controlling home appliances through a mobile application and voice commands.",
    technologies: ["Python", "Raspberry Pi", "MQTT", "Flutter"],
    imageUrl: "https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
  },
  {
    id: 4,
    title: "Stock Market Predictor",
    description: "Machine learning model to predict stock market trends using historical data and sentiment analysis.",
    technologies: ["Python", "TensorFlow", "Pandas", "Scikit-learn"],
    imageUrl: "https://images.pexels.com/photos/6801874/pexels-photo-6801874.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
  }
];

export const skills: Skill[] = [
  { name: "HTML/CSS", level: 5, category: "frontend" },
  { name: "JavaScript", level: 4, category: "frontend" },
  { name: "React", level: 4, category: "frontend" },
  { name: "TypeScript", level: 3, category: "frontend" },
  { name: "Java", level: 4, category: "backend" },
  { name: "Python", level: 5, category: "backend" },
  { name: "Node.js", level: 3, category: "backend" },
  { name: "SQL", level: 4, category: "backend" },
  { name: "MongoDB", level: 3, category: "backend" },
  { name: "Git", level: 4, category: "other" },
  { name: "Docker", level: 3, category: "other" },
  { name: "Linux", level: 4, category: "other" }
];

export const education: Education[] = [
  {
    degree: "Bachelor of Technology in Computer Science",
    institution: "Example Institute of Technology",
    duration: "2020 - 2024",
    description: "Currently pursuing BTech in Computer Science with a focus on Artificial Intelligence and Machine Learning. Maintaining a CGPA of 8.5/10."
  },
  {
    degree: "Higher Secondary Education",
    institution: "Example Public School",
    duration: "2018 - 2020",
    description: "Completed 12th grade with 92% marks in Science stream with Computer Science as an elective subject."
  },
  {
    degree: "Secondary Education",
    institution: "Example Public School",
    duration: "2016 - 2018",
    description: "Completed 10th grade with 94% marks."
  }
];

export const socialLinks: SocialLink[] = [
  {
    platform: "GitHub",
    url: "https://github.com/uditbisht",
    icon: "Github"
  },
  {
    platform: "LinkedIn",
    url: "https://linkedin.com/in/uditbisht",
    icon: "Linkedin"
  },
  {
    platform: "Twitter",
    url: "https://twitter.com/uditbisht",
    icon: "Twitter"
  },
  {
    platform: "Email",
    url: "mailto:udit.bisht@example.com",
    icon: "Mail"
  }
];