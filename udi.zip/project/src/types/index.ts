export interface Project {
  id: number;
  title: string;
  description: string;
  technologies: string[];
  imageUrl?: string;
  link?: string;
}

export interface Skill {
  name: string;
  level: number; // 1-5
  category: 'frontend' | 'backend' | 'other';
}

export interface Education {
  degree: string;
  institution: string;
  duration: string;
  description: string;
}

export interface SocialLink {
  platform: string;
  url: string;
  icon: string;
}