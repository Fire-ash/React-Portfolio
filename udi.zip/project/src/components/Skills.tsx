import React from 'react';
import { skills } from '../data/data';

const SkillBar: React.FC<{ name: string; level: number }> = ({ name, level }) => {
  return (
    <div className="mb-4">
      <div className="flex justify-between mb-1">
        <span className="text-gray-800 dark:text-gray-200 font-medium">{name}</span>
        <span className="text-gray-600 dark:text-gray-400 text-sm">{level}/5</span>
      </div>
      <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
        <div 
          className="h-full bg-blue-600 dark:bg-blue-500 rounded-full transition-all duration-1000" 
          style={{ width: `${(level / 5) * 100}%` }}
        ></div>
      </div>
    </div>
  );
};

const Skills: React.FC = () => {
  const frontendSkills = skills.filter(skill => skill.category === 'frontend');
  const backendSkills = skills.filter(skill => skill.category === 'backend');
  const otherSkills = skills.filter(skill => skill.category === 'other');

  return (
    <section id="skills" className="py-16 md:py-24 bg-gray-50 dark:bg-gray-800">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center text-blue-900 dark:text-blue-300">
          My Skills
        </h2>
        
        <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="bg-white dark:bg-gray-900 rounded-lg shadow-lg p-6 transition-transform hover:scale-105">
            <h3 className="text-xl font-semibold mb-6 text-blue-800 dark:text-blue-400 pb-2 border-b border-gray-200 dark:border-gray-700">
              Frontend Development
            </h3>
            <div className="space-y-4">
              {frontendSkills.map(skill => (
                <SkillBar key={skill.name} name={skill.name} level={skill.level} />
              ))}
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-900 rounded-lg shadow-lg p-6 transition-transform hover:scale-105">
            <h3 className="text-xl font-semibold mb-6 text-blue-800 dark:text-blue-400 pb-2 border-b border-gray-200 dark:border-gray-700">
              Backend Development
            </h3>
            <div className="space-y-4">
              {backendSkills.map(skill => (
                <SkillBar key={skill.name} name={skill.name} level={skill.level} />
              ))}
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-900 rounded-lg shadow-lg p-6 transition-transform hover:scale-105 md:col-span-2 lg:col-span-1">
            <h3 className="text-xl font-semibold mb-6 text-blue-800 dark:text-blue-400 pb-2 border-b border-gray-200 dark:border-gray-700">
              Tools & Technologies
            </h3>
            <div className="space-y-4">
              {otherSkills.map(skill => (
                <SkillBar key={skill.name} name={skill.name} level={skill.level} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;