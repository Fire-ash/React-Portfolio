import React from 'react';
import { aboutMeData } from '../data/data';

const About: React.FC = () => {
  return (
    <section id="about" className="py-16 md:py-24 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center text-blue-900 dark:text-blue-300">
            About Me
          </h2>
          
          <div className="bg-gray-50 dark:bg-gray-800 rounded-lg shadow-lg p-6 md:p-8">
            <div className="flex flex-col md:flex-row gap-8">
              <div className="md:w-1/3 flex justify-center">
                <div className="w-48 h-48 md:w-full md:h-auto aspect-square rounded-full overflow-hidden border-4 border-blue-600 dark:border-blue-400 shadow-lg">
                  <img 
                    src="https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                    alt="Udit Bisht"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              
              <div className="md:w-2/3">
                <h3 className="text-xl font-semibold mb-4 text-blue-800 dark:text-blue-400">
                  {aboutMeData.name} - {aboutMeData.title}
                </h3>
                
                <div className="space-y-4 text-gray-700 dark:text-gray-300">
                  {aboutMeData.description.split('\n\n').map((paragraph, index) => (
                    <p key={index} className="leading-relaxed">
                      {paragraph}
                    </p>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;