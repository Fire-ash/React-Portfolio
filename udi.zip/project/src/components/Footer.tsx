import React from 'react';
import { socialLinks } from '../data/data';
import { ArrowUp, Github, Twitter, Linkedin, Mail } from 'lucide-react';

const iconMap = {
  Github,
  Twitter,
  Linkedin,
  Mail
};

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <footer className="bg-gray-900 dark:bg-gray-950 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center">
          <h2 className="text-2xl font-bold text-blue-400 mb-6">Udit Bisht</h2>
          
          <div className="flex space-x-6 mb-8">
            {socialLinks.map((link, index) => {
              const Icon = iconMap[link.icon as keyof typeof iconMap];
              return (
                <a
                  key={index}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-blue-400 transition-colors"
                  aria-label={link.platform}
                >
                  <Icon size={20} />
                </a>
              );
            })}
          </div>
          
          <div className="text-center mb-8">
            <p className="text-gray-400 mb-2">
              &copy; {currentYear} Udit Bisht. All rights reserved.
            </p>
            <p className="text-gray-500 text-sm">
              Designed with 💙 by Udit Bisht
            </p>
          </div>
          
          <button
            onClick={scrollToTop}
            className="p-3 bg-blue-800 hover:bg-blue-700 rounded-full shadow-lg transition-all hover:scale-110"
            aria-label="Scroll to top"
          >
            <ArrowUp size={20} className="text-white" />
          </button>
        </div>
      </div>
    </footer>
  );
};

export default Footer;