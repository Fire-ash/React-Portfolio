import React from 'react';
import { education } from '../data/data';
import { GraduationCap, Calendar } from 'lucide-react';

const Education: React.FC = () => {
  return (
    <section id="education" className="py-16 md:py-24 bg-gray-50 dark:bg-gray-800">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center text-blue-900 dark:text-blue-300">
          Education
        </h2>
        
        <div className="max-w-3xl mx-auto">
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-0 md:left-1/2 transform md:-translate-x-1/2 h-full w-0.5 bg-blue-600 dark:bg-blue-500"></div>
            
            {/* Education items */}
            <div className="space-y-12">
              {education.map((item, index) => (
                <div 
                  key={index} 
                  className={`relative flex flex-col md:flex-row md:items-center gap-4 ${
                    index % 2 === 0 ? 'md:flex-row-reverse' : ''
                  }`}
                >
                  {/* Timeline dot */}
                  <div className="absolute left-0 md:left-1/2 transform -translate-x-1/2 w-6 h-6 rounded-full bg-blue-600 dark:bg-blue-500 z-10 flex items-center justify-center">
                    <GraduationCap size={16} className="text-white" />
                  </div>
                  
                  {/* Content */}
                  <div className={`flex-1 ml-8 md:ml-0 ${
                    index % 2 === 0 ? 'md:pr-8 md:text-right' : 'md:pl-8'
                  }`}>
                    <div className="bg-white dark:bg-gray-900 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                      <h3 className="text-xl font-bold mb-2 text-blue-800 dark:text-blue-400">
                        {item.degree}
                      </h3>
                      <h4 className="text-lg font-medium mb-2 text-gray-700 dark:text-gray-300">
                        {item.institution}
                      </h4>
                      <div className="flex items-center mb-4 text-gray-600 dark:text-gray-400">
                        <Calendar size={16} className="mr-2" />
                        <span>{item.duration}</span>
                      </div>
                      <p className="text-gray-700 dark:text-gray-300">
                        {item.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Education;