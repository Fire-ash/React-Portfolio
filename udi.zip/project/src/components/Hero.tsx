import React from 'react';
import { ArrowDown } from 'lucide-react';
import { aboutMeData } from '../data/data';

const Hero: React.FC = () => {
  const scrollToAbout = () => {
    const aboutSection = document.getElementById('about');
    if (aboutSection) {
      aboutSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="min-h-screen flex items-center justify-center relative bg-gradient-to-br from-blue-100 to-white dark:from-blue-950 dark:to-gray-900">
      <div className="absolute inset-0 bg-grid-pattern opacity-10 dark:opacity-5"></div>
      <div className="container mx-auto px-4 py-16 md:py-24 flex flex-col items-center text-center z-10">
        <h1 className="text-4xl md:text-6xl font-bold mb-4 text-blue-900 dark:text-blue-300 animate-fadeIn">
          {aboutMeData.name}
        </h1>
        <h2 className="text-xl md:text-2xl font-medium mb-8 text-gray-600 dark:text-gray-300 animate-fadeIn animation-delay-200">
          {aboutMeData.title}
        </h2>
        <p className="max-w-2xl text-lg text-gray-700 dark:text-gray-300 mb-12 animate-fadeIn animation-delay-400">
          {aboutMeData.shortDescription}
        </p>
        <div className="flex flex-col sm:flex-row gap-4 animate-fadeIn animation-delay-600">
          <button 
            onClick={scrollToAbout}
            className="px-6 py-3 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors shadow-lg hover:shadow-xl dark:bg-blue-800 dark:hover:bg-blue-700 flex items-center justify-center"
          >
            Learn More
            <ArrowDown size={18} className="ml-2" />
          </button>
          <a 
            href="#contact" 
            className="px-6 py-3 border-2 border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400 rounded-full hover:bg-blue-600 hover:text-white dark:hover:bg-blue-700 transition-colors shadow-lg hover:shadow-xl"
          >
            Get In Touch
          </a>
        </div>
      </div>
      
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <button 
          onClick={scrollToAbout}
          className="p-2 rounded-full bg-white dark:bg-gray-800 shadow-md hover:shadow-lg transition-shadow"
          aria-label="Scroll down"
        >
          <ArrowDown size={24} className="text-blue-600 dark:text-blue-400" />
        </button>
      </div>
    </section>
  );
};

export default Hero;